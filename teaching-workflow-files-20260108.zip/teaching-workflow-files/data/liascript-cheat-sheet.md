# LiaScript Quick Reference Guide

## Course Metadata (Header)

Every LiaScript course must start with metadata in HTML comments:

```lia
<!--
author:   Your Name
email:    your.email@example.com
version:  1.0.0
language: en
narrator: English Female
comment:  Brief course description
-->
```

**Fields:**
- `author`: Course creator name
- `email`: Contact email
- `version`: Semantic versioning (1.0.0)
- `language`: Language code (en, de, fr, etc.)
- `narrator`: Text-to-speech voice
- `comment`: Short course description

## Structure: Headings & Slides

```lia
# Course Title (Main Title - Use Once)
## Section 1 (Creates a new slide)
### Subsection (Only inside containers!)
```

**Rules:**
- `#` = Course title (use exactly once)
- `##` = New slide (each creates a separate slide)
- `###` to `######` = Sub-headings (ONLY inside HTML blocks, lists, or blockquotes)

**CRITICAL:** Never use sub-headings directly in slide content. Always wrap them:

```lia
## Slide Title

<div>
### This is allowed inside a div
Content here...
</div>

- List item
  - ### This is allowed in a list
```

## Animations & Narration

Control when content appears and what the narrator says:

```lia
## My Slide

    --{{0}}--
This text will be read aloud when the slide first loads.

      {{0}}
This content appears at step 0 (immediately).

    --{{1}}--
This will be read when the user advances to step 1.

      {{1}}
This content appears at step 1.

      {{2-3}}
This appears at step 2 and disappears at step 3.
```

**Key Points:**
- `--{{n}}--` = Narrator text for step n (indented with 4 spaces)
- `{{n}}` = Content appears at step n (indented with 6 spaces)
- `{{a-b}}` = Content visible from step a to b
- Numbering resets with each new `##` slide

## Text Formatting

```lia
Normal text

**Bold text**

*Italic text*

***Bold and italic***

> Blockquote / Important note

~~Strikethrough~~
```

## Lists

```lia
Unordered list:
- Item 1
- Item 2
  - Nested item

Ordered list:
1. First
2. Second
3. Third
```

## Links & Media

```lia
[Link text](https://example.com)

![Image alt text](path/to/image.jpg "Optional caption")

?[Audio title](path/to/audio.mp3 "Optional caption")

!?[Video title](https://youtube.com/watch?v=VIDEO_ID "Optional caption")

??[oEmbed content](https://example.com/resource)
```

**Media Gallery:** Place multiple media items consecutively to create a gallery.

## Code Blocks

````lia
```python
def hello_world():
    print("Hello, World!")
```
````

**Executable Code:**

````lia
```python
x = 5 + 3
print(x)
```
<script>
@input
</script>
````

## Diagrams

**Mermaid Diagrams:**

````lia
```mermaid @mermaid
graph TD;
    A-->B;
    A-->C;
    B-->D;
    C-->D;
```
````

**ASCII Art:**

````lia
```ascii
  +---+      +---+
  | A | *--> | B |
  +---+      +---+
```
````

## Mathematical Formulas

Inline: `$E = mc^2$`

Block:
```lia
$$
\sum_{i=1}^{n} i = rac{n(n+1)}{2}
$$
```

## Quizzes & Interactions

**Single Choice:**

```lia
What is 2 + 2?

- [( )] 3
- [(X)] 4  (X marks correct answer)
- [( )] 5
```

**Multiple Choice:**

```lia
Select all prime numbers:

- [[X]] 2
- [[ ]] 4
- [[X]] 5
- [[ ]] 6
```

**Text Input:**

```lia
Who wrote "Hamlet"?

[[Shakespeare]]
```

**Free Text:**

```lia
Explain the concept:

[[?]]
```

## Tables

```lia
| Column 1 | Column 2 | Column 3 |
|----------|----------|----------|
| Value 1  | Value 2  | Value 3  |
| Value 4  | Value 5  | Value 6  |
```

## Text-to-Speech (TTS)

**Play Button for Section:**

```lia
    {{|>}}
This text will be read when the user clicks the play button.
```

**Play Button with Animation:**

```lia
    {{|> English Female 1-2}}
This is read aloud, appears at step 1, disappears at step 2.
```

**Change Narrator:**

```lia
## Section with Different Voice
<!--
narrator: German Male
-->

    --{{0}}--
Dieser Text wird auf Deutsch vorgelesen.
```

## Importing Content

```lia
@import(./other-file.md)

@include(https://example.com/content.md)
```

## Best Practices

1. **One slide, one concept**: Keep slides focused
2. **Progressive disclosure**: Use animations to reveal content step-by-step
3. **Narrator alignment**: Ensure `--{{n}}--` text explains what appears at `{{n}}`
4. **Alt text**: Always provide descriptive alt text for images
5. **Short code blocks**: Keep examples concise and focused
6. **Test interactivity**: Preview all quizzes and interactive elements

## Common Mistakes to Avoid

❌ **Don't:** Use sub-headings outside containers
```lia
## Slide
### This breaks the slide structure!
```

✓ **Do:** Wrap sub-headings in containers
```lia
## Slide
<div>
### This is correct
</div>
```

❌ **Don't:** Forget to close code blocks
````lia
```python
code here
(missing closing backticks)
````

✓ **Do:** Always close code blocks with matching backticks

❌ **Don't:** Use wrong animation indices
```lia
--{{0}}--
Text for step 0

  {{2}}  (Skips step 1!)
Content at step 2
```

✓ **Do:** Use sequential numbering
```lia
--{{0}}--
Text for step 0

  {{0}}
Content at step 0

--{{1}}--
Text for step 1

  {{1}}
Content at step 1
```

## Example Complete Slide

```lia
## Introduction to Variables

    --{{0}}--
Variables are containers for storing data values. Think of them as labeled boxes
where you can put information and retrieve it later.

      {{0}}
**What is a Variable?**

A variable is a named storage location in computer memory.

    --{{1}}--
Let's see a simple example in Python.

      {{1}}
```python
# Creating a variable
name = "Alice"
age = 25
```

    --{{2}}--
Variables have three important properties: name, value, and type.

      {{2}}
> **Key Point**: Variable names should be descriptive and follow naming conventions.

## Resources

- [LiaScript Official Docs](https://liascript.github.io/)
- [LiaScript GitHub](https://github.com/LiaScript/LiaScript)
- [Course Examples](https://liascript.github.io/course/)
