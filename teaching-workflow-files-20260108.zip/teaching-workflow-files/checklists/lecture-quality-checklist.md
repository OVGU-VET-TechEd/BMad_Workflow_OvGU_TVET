# Checklist: Lecture Quality

## Outline
- [ ] Title present
- [ ] Target audience clearly defined
- [ ] Time commitment specified
- [ ] Summary complete
- [ ] Learning objectives formulated (3-5)
- [ ] Optional: Logo prompt included

## Didactics
- [ ] References outline content
- [ ] Didactic concept clear and detailed
- [ ] Professor persona defined
- [ ] Style & difficulty level specified
- [ ] Course type established

## Agenda
- [ ] Learning objectives adopted from outline
- [ ] Sessions complete with:
  - [ ] Title
  - [ ] Duration
  - [ ] Type (lecture/exercise)
  - [ ] Learning objective(s)
  - [ ] Summary
  - [ ] Materials file path

## Session Skeletons
- [ ] Exist for all planned sessions
- [ ] Contain all required sections:
  - [ ] Title
  - [ ] Summary
  - [ ] Content outline
  - [ ] Activities
  - [ ] References

## Session Materials
- [ ] All skeletons promoted to materials
- [ ] Detailed structure with sub-chapters
- [ ] References included per section
- [ ] Didactic inputs considered
- [ ] LiaScript syntax correct
- [ ] Animation sequences logical

## Overall Consistency
- [ ] Outline ↔ Didactics ↔ Agenda ↔ Sessions consistent
- [ ] No sessions without materials
- [ ] Numbering scheme correct
- [ ] Markdown format uniform across files
- [ ] Professor persona maintained throughout
- [ ] All learning objectives covered in materials
