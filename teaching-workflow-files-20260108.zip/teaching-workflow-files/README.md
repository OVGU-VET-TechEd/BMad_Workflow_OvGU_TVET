# BMad-Method Teaching Workflow Files

This package contains all template files, task definitions, and resources for the
BMad-Method Teaching Material Generation Workflow.

## Contents

### Templates (`templates/`)
YAML template files that define the structure for each document type:
- `lecture-outline-template.yaml` - Course overview and objectives
- `lecture-didactics-template.yaml` - Teaching approach and persona
- `lecture-agenda-template.yaml` - Session planning
- `session-skeleton.yaml` - Basic session structure
- `session-material.yaml` - Full session content

### Tasks (`tasks/`)
Step-by-step task definitions for each workflow stage:
- `create-outline.md` - Creating course outline
- `create-didactics.md` - Defining teaching approach
- `create-agenda.md` - Planning sessions
- `create-session-skeleton.md` - Generating session skeletons
- `promote-session.md` - Converting skeletons to materials
- `coauthor-materials.md` - Interactive content refinement
- `validate-lecture.md` - Quality checking
- `assemble-bundle.md` - Final packaging

### Checklists (`checklists/`)
- `lecture-quality-checklist.md` - Comprehensive quality checklist

### Data (`data/`)
- `liascript-cheat-sheet.md` - Complete LiaScript syntax reference

### Agent Configuration (`.bmad-core/`)
- `agents/teaching-agent.md` - Teaching-Agent definition and behavior

### Main Files
- `.github/copilot-instructions.md` - Instructions for AI assistant integration
- `README.md` - This file

## Usage

### 1. Setup Your Project

Copy these files into your VS Code project:

```bash
# Create your project directory
mkdir my-lecture-project
cd my-lecture-project

# Copy the files from this package
cp -r teaching-workflow-files/* .
```

### 2. Configure VS Code

Ensure you have:
- Visual Studio Code installed
- GitHub Copilot extension with Claude API access
- (Optional) Local LLM like DeepSeek with Ollama

Place `.github/copilot-instructions.md` in your project so the AI assistant
can follow the Teaching-Agent persona.

### 3. Start Creating Content

Open VS Code in your project and use commands:

```
/create-outline
/create-didactics
/create-agenda
/create-session 1 lecture "Introduction"
/promote-session 1 lecture
/coauthor-materials
```

### 4. Directory Structure

After setup, create these directories in your project:

```
my-lecture-project/
├── docs/              (Generated documents)
├── skeletons/         (Session skeletons)
├── materials/         (Full session materials)
├── templates/         (From this package)
├── tasks/             (From this package)
├── checklists/        (From this package)
├── data/              (From this package)
├── .bmad-core/        (From this package)
└── .github/
    └── copilot-instructions.md
```

## File Descriptions

### Templates
Each YAML template defines the structure and required fields for a document type.
The AI assistant uses these to generate consistent, well-structured content.

### Tasks
Task files provide step-by-step instructions for the AI assistant to follow
when executing each command. They ensure consistency and completeness.

### Checklists
Quality assurance checklist for validating your complete lecture package.

### Data
Reference materials and syntax guides for creating content.

## Getting Help

- Read the main documentation (VS Code AI Teaching Workflow Setup Guide)
- Check the LiaScript cheat sheet in `data/liascript-cheat-sheet.md`
- Use `/help` command in your AI assistant
- Review example files in the documentation

## Version

Version: 1.0.0
Created: 2026-01-08

## License

These templates and workflow definitions are provided for educational use.
