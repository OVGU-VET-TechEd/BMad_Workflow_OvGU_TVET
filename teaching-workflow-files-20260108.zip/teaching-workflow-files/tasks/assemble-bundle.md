# Task: assemble-bundle

## Purpose
Assembles all lecture documents into a complete package.

## Output
- `lecture-bundle/` directory or `.zip` file

## Steps
1. Collect all documents from docs/, skeletons/, materials/
2. Build organized structure
3. Create index file `bundle-index.md` with table of contents
4. Bundle everything into distributable format
