# Task: promote-session

## Purpose
Converts a **Session Skeleton** into detailed **Session Material**.
**Agent adopts professor persona from didactics**.

## Inputs
- number, type
- skeleton: File from `skeletons/`
- didactics: Content from `docs/lecture-didactics.md`
- agenda: Content from `docs/lecture-agenda.md`
- **Professor persona from `docs/lecture-didactics.md` (mandatory handoff)**
- **Style & difficulty from `docs/lecture-didactics.md` (mandatory handoff)**

## Output
- `materials/{number}-{type}.md`
- Structure based on `templates/session-material.yaml`

## Steps
1. Load skeleton
2. Adopt didactic concept and course type from didactics
3. **Agent adopts professor persona & style from didactics**
4. Insert agenda info
5. Consider didactic inputs
6. Generate planned structure
7. Apply template
8. Save file
