# Task: create-session-skeleton

## Purpose
Creates a **Session Skeleton** (lecture or exercise) as structured foundation.
**Agent adopts professor persona and style from didactics**.

## Inputs
- number: Session number
- type: Session type (`lecture` or `exercise`)
- title (optional)
- Didactic concept from `docs/lecture-didactics.md`
- **Professor persona from `docs/lecture-didactics.md` (mandatory handoff)**
- **Style & difficulty from `docs/lecture-didactics.md` (mandatory handoff)**

## Output
- `skeletons/{number}-{type}.md` (Markdown file)
- Structure based on `templates/session-skeleton.yaml`

## Steps
1. Capture session number, type and optional title
2. Adopt didactic concept and course type from didactics
3. **Agent adopts professor persona & style from didactics**
4. Generate basic structure for session
5. Fill template `templates/session-skeleton.yaml`
6. Save file
