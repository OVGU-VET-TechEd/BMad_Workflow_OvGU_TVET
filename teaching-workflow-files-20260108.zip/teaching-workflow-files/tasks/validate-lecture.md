# Task: validate-lecture

## Purpose
Checks consistency and completeness of all lecture documents based on didactics
and checklist.

## Output
- `docs/validation-report.md`

## Steps
1. Load and use structure from `checklists/lecture-quality-checklist.md`
2. Check outline
3. Check didactics
4. Check agenda
5. Check session skeletons
6. Check materials
7. Generate report with findings
